package servlet;

import model.Contact;
import model.ContactDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class AddContactServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String address = request.getParameter("address");

        Contact c = new Contact(0, name, phone, email, address);
        ContactDAO.addContact(c);

        response.sendRedirect("viewContacts.jsp");
    }
}