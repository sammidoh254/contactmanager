package servlet;

import model.Contact;
import model.ContactDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class EditContactServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String address = request.getParameter("address");

        Contact c = new Contact(id, name, phone, email, address);
        ContactDAO.updateContact(c);

        response.sendRedirect("viewContacts.jsp");
    }
}